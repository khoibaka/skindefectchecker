//
//  ViewController.swift
//  HackCWRU Prototype
//
//  Created by Hieu Pham on 2/7/20.
//  Copyright © 2020 Hieu Pham. All rights reserved.
//

import UIKit
import MobileCoreServices

class CameraViewController: UIViewController, UIImagePickerControllerDelegate,
    UINavigationControllerDelegate
{
    var dataController: PatientDataController!
    
    @IBOutlet weak var takenImage: UIImageView!
    
    @IBAction func takePicture(_ sender: AnyObject) {
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
//            let imageWidth = 100.0
//            let imageHeight = 100.0
//            let width = 50.0
//            let height = 50.0
//            let origin = CGPoint(x: (imageWidth - width)/2, y: (imageHeight - height)/2)
//            let size = CGSize(width: width, height: height)
            takenImage.contentMode = .scaleToFill
            //takenImage.image = pickedImage.cropImage(rect: CGRect(origin: origin, size: size))
            takenImage.image = pickedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
}

extension UIImage{
    func cropImage(rect: CGRect)-> UIImage {
        var rect = rect
        rect.origin.x = self.scale
        rect.origin.y = self.scale
        rect.size.width = self.scale
        rect.size.height = self.scale
        
        let imageRef = self.cgImage!.cropping(to: rect)!
        let image = UIImage(cgImage: imageRef, scale: self.scale, orientation: self.imageOrientation)
        return image
    }
}


