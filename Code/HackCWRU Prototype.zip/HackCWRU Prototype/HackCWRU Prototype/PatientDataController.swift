//
//  PatientDataController.swift
//  HackCWRU Prototype
//
//  Created by Hieu Pham on 2/8/20.
//  Copyright © 2020 Hieu Pham. All rights reserved.
//

import Foundation

class PatientDataController {
    // a patient with default meaningless value
    var currentPatient = PatientData(age: 1, gender: 3, skinLocation: 0)
}
